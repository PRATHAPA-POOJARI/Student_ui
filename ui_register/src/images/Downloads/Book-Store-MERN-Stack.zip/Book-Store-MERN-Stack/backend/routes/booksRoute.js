import express from 'express';
import { Book } from '../models/bookModel.js';

const router = express.Router();

// Middleware to validate required fields
const validateFields = (request, response, next) => {
  if (!request.body.title || !request.body.author || !request.body.publishYear) {
    return response.status(400).json({
      message: 'Send all required fields: title, author, publishYear',
    });
  }
  next();
};

// Error handling middleware
const errorHandler = (error, request, response, next) => {
  console.error(error.message);
  response.status(500).json({ message: error.message });
};

// Route for Save a new Book
router.post('/', validateFields, async (request, response, next) => {
  try {
    const newBook = {
      title: request.body.title,
      author: request.body.author,
      publishYear: request.body.publishYear,
    };
    const book = await Book.create(newBook);
    response.status(201).json(book);
  } catch (error) {
    next(error);
  }
});

// Route for Get All Books from database
router.get('/', async (request, response, next) => {
  try {
    const books = await Book.find({});
    response.status(200).json({
      count: books.length,
      data: books,
    });
  } catch (error) {
    next(error);
  }
});

// Route for Get One Book from database by id
router.get('/:id', async (request, response, next) => {
  try {
    const { id } = request.params;
    const book = await Book.findById(id);
    response.status(200).json(book);
  } catch (error) {
    next(error);
  }
});

// Route for Update a Book
router.put('/:id', validateFields, async (request, response, next) => {
  try {
    const { id } = request.params;
    const result = await Book.findByIdAndUpdate(id, request.body);
    if (!result) {
      return response.status(404).json({ message: 'Book not found' });
    }
    response.status(200).json({ message: 'Book updated successfully' });
  } catch (error) {
    next(error);
  }
});

// Route for Delete a book
router.delete('/:id', async (request, response, next) => {
  try {
    const { id } = request.params;
    const result = await Book.findByIdAndDelete(id);
    if (!result) {
      return response.status(404).json({ message: 'Book not found' });
    }
    response.status(200).json({ message: 'Book deleted successfully' });
  } catch (error) {
    next(error);
  }
});

// Error handling middleware
router.use(errorHandler);

export default router;
